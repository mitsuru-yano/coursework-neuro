from influxdb_client import InfluxDBClient, Point, WritePrecision
from app.config import INFLUX_URL, INFLUX_TOKEN, INFLUX_ORG, INFLUX_BUCKET

client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
write_api = client.write_api(write_options=WritePrecision.NS)
query_api = client.query_api()

def write_point(measurement: str, fields: dict, tags: dict = None):
    point = Point(measurement)
    for key, value in fields.items():
        point.field(key, value)
    if tags:
        for key, value in tags.items():
            point.tag(key, value)
    write_api.write(bucket=INFLUX_BUCKET, org=INFLUX_ORG, record=point)
